package com.example.ankolayout

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class dataClass(
    val title: String,
    val description: String,
    val imageView: Int):Parcelable
